
/*
 * Auto generated Run-Time-Environment Configuration File
 *      *** Do not modify ! ***
 *
 * Project: 'helloworld@stm32l476rg-nucleo' 
 * Target:  'helloworld@stm32l476rg-nucleo' 
 */

#ifndef RTE_COMPONENTS_H
#define RTE_COMPONENTS_H


/*
 * Define the Device Header File: 
 */
#define CMSIS_device_header "stm32l4xx.h"



#endif /* RTE_COMPONENTS_H */
